const API_BASE = '/api'; // if your backend is hosted elsewhere, change this to full URL

const $ = id => document.getElementById(id);
const form = $('assessmentForm');
const result = $('result');
const errorBox = $('error');
const healthBtn = $('healthBtn');
const healthStatus = $('healthStatus');
const clearBtn = $('clearBtn');

function showResult(data){
  result.classList.remove('hidden');
  errorBox.classList.add('hidden');
  result.innerHTML = `<strong>Assessment result</strong>
  <pre>${JSON.stringify(data, null, 2)}</pre>`;
}

function showError(msg){
  errorBox.classList.remove('hidden');
  result.classList.add('hidden');
  errorBox.textContent = msg;
}

form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const payload = {
    modelName: $('modelName').value.trim(),
    description: $('description').value.trim(),
    dataType: $('dataType').value.trim(),
    timestamp: new Date().toISOString()
  };

  showError(''); result.classList.add('hidden');
  try{
    const resp = await fetch(`${API_BASE}/assess`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });

    if(!resp.ok){
      const txt = await resp.text();
      throw new Error(`Server returned ${resp.status}: ${txt}`);
    }

    const data = await resp.json();
    showResult(data);
  }catch(err){
    showError(err.message);
  }
});

clearBtn.addEventListener('click', ()=>{
  form.reset();
  result.classList.add('hidden');
  errorBox.classList.add('hidden');
});

healthBtn.addEventListener('click', async ()=>{
  healthStatus.textContent = 'Checking...';
  try{
    const r = await fetch(`${API_BASE}/status`);
    if(!r.ok) throw new Error(`status ${r.status}`);
    const j = await r.json();
    healthStatus.textContent = `OK — ${j.status || 'healthy'}`;
  }catch(e){
    healthStatus.textContent = `Down (${e.message})`;
  }
});